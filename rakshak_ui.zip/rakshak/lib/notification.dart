import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class NotificationPage extends StatelessWidget {
  final List<Map<String, dynamic>> notifications = [
    {
      "sender": "Anyone",
      "message": "sent a message",
      "title": "TITLE OF MESSAGE",
      "content": "MESSAGES",
      "time": DateTime(2023, 7, 8, 16, 31),
      "color": Colors.purple[200],
      "isHighlighted": true,
    },
    {
      "sender": "Rupam",
      "message": "wants to help you",
      "title": "TITLE OF MESSAGE",
      "content": "Some safety messages",
      "time": DateTime(2023, 7, 8, 16, 30),
      "color": Colors.purple[200],
      "isHighlighted": false,
    },
    {
      "sender": "Ricky",
      "message": "sent a Safety guidance",
      "title": "FlutterFlow CRM App",
      "content":
          "\"Please review the updates to this document and get back with me.\"",
      "time": DateTime(2023, 7, 8, 14, 20),
      "color": Colors.teal[200],
      "isHighlighted": false,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Notifications',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 16),
              Expanded(
                child: ListView.builder(
                  itemCount: notifications.length,
                  itemBuilder: (context, index) {
                    return _buildNotificationItem(notifications[index]);
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNotificationItem(Map<String, dynamic> notification) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            backgroundColor: notification['color'],
            child: Text(
              notification['sender'][0],
              style: TextStyle(color: Colors.white),
            ),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                RichText(
                  text: TextSpan(
                    style: TextStyle(color: Colors.black, fontSize: 16),
                    children: [
                      TextSpan(
                        text: "${notification['sender']} ",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      TextSpan(text: notification['message']),
                    ],
                  ),
                ),
                SizedBox(height: 8),
                Container(
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: notification['isHighlighted']
                        ? Colors.purple[50]
                        : Colors.grey[200],
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        notification['title'],
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 4),
                      Text(notification['content']),
                    ],
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  DateFormat('MMM d, at h:mma').format(notification['time']),
                  style: TextStyle(color: Colors.grey[600], fontSize: 12),
                ),
              ],
            ),
          ),
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.blue,
            ),
          ),
        ],
      ),
    );
  }
}
