import 'package:flutter/material.dart';

void main() {
  runApp(const SettingsApp());
}

class SettingsApp extends StatelessWidget {
  const SettingsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Settings Page',
      home: SettingsPage(),
    );
  }
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: Icon(Icons.arrow_back, color: Colors.black), // Back arrow
        title: Text(
          'Settings Page',
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Settings options
            ListTile(
              title: Text('Getting Started'),
              trailing: Icon(Icons.arrow_forward_ios),
              onTap: () {}, // Define action here
            ),
            ListTile(
              title: Text('About Us'),
              trailing: Icon(Icons.arrow_forward_ios),
              onTap: () {}, // Define action here
            ),
            ListTile(
              title: Text('Help'),
              trailing: Icon(Icons.arrow_forward_ios),
              onTap: () {}, // Define action here
            ),
            ListTile(
              title: Text('Privacy Policy'),
              trailing: Icon(Icons.arrow_forward_ios),
              onTap: () {}, // Define action here
            ),
            ListTile(
              title: Text('Terms & Conditions'),
              trailing: Icon(Icons.arrow_forward_ios),
              onTap: () {}, // Define action here
            ),
            SizedBox(height: 30),
            // Social media section
            Text(
              'Follow us on',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
            SizedBox(height: 10),
            Row(
              children: [
                // Social media icons
                IconButton(
                  icon: Icon(Icons.youtube_searched_for),
                  onPressed: () {}, // Define action here
                ),
                IconButton(
                  icon: Icon(Icons.camera_alt), // Placeholder for Instagram
                  onPressed: () {}, // Define action here
                ),
                IconButton(
                  icon: Icon(Icons.facebook),
                  onPressed: () {}, // Define action here
                ),
                IconButton(
                  icon: Icon(Icons.linked_camera), // Placeholder for LinkedIn
                  onPressed: () {}, // Define action here
                ),
              ],
            ),
            Spacer(),
            // Logout button
            Center(
              child: OutlinedButton(
                onPressed: () {}, // Define action here
                child: Text(
                  'Log Out',
                  style: TextStyle(color: Colors.black),
                ),
              ),
            ),
            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
