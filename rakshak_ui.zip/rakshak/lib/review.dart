import 'package:flutter/material.dart';

class ReviewPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Review'),
        actions: [
          IconButton(
            icon: Icon(Icons.chat_bubble_outline),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        children: [
          _buildTabs(),
          Expanded(
            child: _buildReviewList(),
          ),
        ],
      ),
    );
  }

  Widget _buildTabs() {
    return Container(
      padding: EdgeInsets.all(16),
      child: Row(
        children: [
          _buildTab('All', isSelected: true),
          SizedBox(width: 8),
          _buildTab('Danger Zone'),
          SizedBox(width: 8),
          _buildTab('About App'),
          SizedBox(width: 8),
          _buildTab('Safe Zone'),
        ],
      ),
    );
  }

  Widget _buildTab(String text, {bool isSelected = false}) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: isSelected ? Colors.deepPurple : Colors.grey[200],
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: isSelected ? Colors.white : Colors.black,
          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
        ),
      ),
    );
  }

  Widget _buildReviewList() {
    return ListView.builder(
      itemCount: 5,
      itemBuilder: (context, index) {
        return _buildReviewItem(index);
      },
    );
  }

  Widget _buildReviewItem(int index) {
    String title;
    String subtitle;

    switch (index) {
      case 0:
        title = 'About APP';
        subtitle = 'some messages';
        break;
      case 1:
        title = 'Discuss About Danger Zone';
        subtitle = 'some messages';
        break;
      case 2:
        title = 'About Safe Zone';
        subtitle = 'some messages';
        break;
      case 3:
        title = 'safety tips';
        subtitle = 'some messages';
        break;
      case 4:
        title = 'about app';
        subtitle = '';
        break;
      default:
        title = 'User Name';
        subtitle = '';
    }

    return ListTile(
      leading: CircleAvatar(
        backgroundColor: Colors.deepPurple,
        child: Icon(Icons.person, color: Colors.white),
      ),
      title: Text(title),
      subtitle: Text(subtitle),
      trailing: Text('4m ago'),
    );
  }
}
