import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF607D8B),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: SingleChildScrollView(
        // Allows scrolling if content overflows
        child: Column(
          children: [
            _buildProfileSection(),
            SizedBox(height: 20), // Adding space between sections
            _buildQuickAccessButtons(),
            SizedBox(height: 20), // Adding space between sections
            _buildSettingsSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileSection() {
    return Column(
      children: [
        CircleAvatar(
          radius: 50,
          backgroundColor: Colors.white,
          child: FlutterLogo(size: 60),
        ),
        SizedBox(height: 10),
        Text(
          'User Name',
          style: TextStyle(
              color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
        ),
        Text(
          'User.N@gmail.com',
          style: TextStyle(color: Colors.white70, fontSize: 16),
        ),
        SizedBox(height: 20),
      ],
    );
  }

  Widget _buildQuickAccessButtons() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Expanded(child: _buildIconButton(Icons.work, 'Your Details')),
          SizedBox(width: 16),
          Expanded(
              child: _buildIconButton(
                  Icons.notifications, 'Tracker\nNotifications')),
          SizedBox(width: 16),
          Expanded(child: _buildIconButton(Icons.help, 'Help Center')),
        ],
      ),
    );
  }

  Widget _buildIconButton(IconData icon, String label) {
    return Column(
      children: [
        CircleAvatar(
          backgroundColor: Colors.white,
          child: Icon(icon, color: Colors.black),
        ),
        SizedBox(height: 5),
        Text(
          label,
          style: TextStyle(color: Colors.white, fontSize: 12),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildSettingsSection() {
    return Container(
      margin: EdgeInsets.only(top: 20),
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(30),
          topRight: Radius.circular(30),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Settings',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          SizedBox(height: 20),
          _buildSettingsItem(Icons.phone, 'Phone Number', 'Add Number'),
          _buildSettingsItem(Icons.language, 'Language', 'English (eng)'),
          _buildSettingsItem(Icons.edit, 'Profile Settings', 'Edit Profile'),
          _buildSettingsItem(Icons.notifications, 'Notification Settings', ''),
          _buildSettingsItem(Icons.logout, 'Log out of account', 'Log Out?'),
        ],
      ),
    );
  }

  Widget _buildSettingsItem(IconData icon, String label, String action) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          Icon(icon, color: Colors.black54),
          SizedBox(width: 15),
          Expanded(child: Text(label, style: TextStyle(fontSize: 16))),
          Text(
            action,
            style: TextStyle(
                color: action == 'Log Out?' ? Colors.red : Colors.blue),
          ),
          if (label == 'Notification Settings')
            Icon(Icons.chevron_right, color: Colors.black54),
        ],
      ),
    );
  }
}
