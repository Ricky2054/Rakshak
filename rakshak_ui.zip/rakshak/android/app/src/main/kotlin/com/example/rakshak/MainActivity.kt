package com.example.rakshak

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
