from flask import Flask, request, jsonify, render_template
import google.generativeai as genai
import googlemaps
import os
from dotenv import load_dotenv
import polyline
import logging

load_dotenv()

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)

gmaps = googlemaps.Client(key=os.getenv('GOOGLE_MAPS_API_KEY'))

genai.configure(api_key=os.getenv('GEMINI_API_KEY'))
model = genai.GenerativeModel('gemini-pro')

INDIAN_HELPLINES = {
    "Women's Helpline": "1091",
    "Police": "100",
    "Emergency": "112",
    "Domestic Abuse": "181",
    "Student/Child Helpline": "1098"
}

def find_police_stations(lat, lng, limit=3):
    result = gmaps.places_nearby(
        location=(lat, lng),
        rank_by="distance",
        type="police"
    )
    
    stations = []
    for place in result['results'][:limit]:
        place_id = place['place_id']
        place_details = gmaps.place(place_id=place_id, fields=['name', 'formatted_address', 'formatted_phone_number', 'website'])['result']
        
        station = {
            'name': place_details.get('name', 'Name not available'),
            'address': place_details.get('formatted_address', 'Address not available'),
            'phone': place_details.get('formatted_phone_number', 'Phone not available'),
            'lat': place['geometry']['location']['lat'],
            'lng': place['geometry']['location']['lng']
        }
        
        if 'website' in place_details:
            station['website'] = place_details['website']
        
        stations.append(station)
    
    return stations

def get_safe_route(origin, destination):
    try:
        directions = gmaps.directions(origin, destination, mode="walking")
        
        if not directions:
            return None
        
        route = directions[0]['legs'][0]
        
        route_polyline = route['overview_polyline']['points']
        route_coords = polyline.decode(route_polyline)
        
        return {
            'polyline': route_polyline,
            'distance': route['distance']['text'],
            'duration': route['duration']['text'],
            'steps': route['steps']
        }
    except Exception as e:
        logging.error(f"Error in get_safe_route: {str(e)}")
        return None

@app.route('/')
def index():
    return render_template('index.html', google_maps_api_key=os.getenv('GOOGLE_MAPS_API_KEY'))

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json['message']
    user_location = request.json.get('location')

    if "safe route" in user_message.lower() or "safest path" in user_message.lower():
        parts = user_message.split(" to ")
        if len(parts) == 2:
            origin = parts[0].replace("safe route from ", "").strip()
            destination = parts[1].strip()
            route_info = get_safe_route(origin, destination)
            if route_info:
                response = f"Safe route found. Distance: {route_info['distance']}, Duration: {route_info['duration']}. Route displayed on map with real-time navigation."
                return jsonify({
                    'response': response,
                    'route_info': route_info
                })
            else:
                return jsonify({
                    'response': f"Couldn't find a route from {origin} to {destination}. Please check the locations and try again."
                })
        else:
            return jsonify({
                'response': "Please provide both origin and destination. For example: 'What's the safe route from Central Park to Times Square?'"
            })

    if "police station" in user_message.lower() or "nearest police" in user_message.lower():
        if user_location:
            police_stations = find_police_stations(user_location['lat'], user_location['lng'])
            if police_stations:
                response = "Nearest police stations:<br>"
                for station in police_stations:
                    response += f"<br><strong>{station['name']}</strong><br>{station['address']}<br>Phone: {station['phone']}<br>"
                return jsonify({
                    'response': response,
                    'location': user_location,
                    'police_stations': police_stations
                })
            else:
                return jsonify({
                    'response': "No nearby police stations found."
                })
        else:
            return jsonify({
                'response': "Please share your location to find nearby police stations."
            })

    if "helpline" in user_message.lower() or "emergency number" in user_message.lower():
        helpline_info = "<p>Important helpline numbers in India:</p><ul>"
        for service, number in INDIAN_HELPLINES.items():
            helpline_info += f"<li><strong>{service}:</strong> {number}</li>"
        helpline_info += "</ul>"
        return jsonify({'response': helpline_info})

    context = (
        "You are Rakshak, an AI assistant focused on women's safety in India. "
        "Provide concise, relevant, and helpful information tailored to the Indian context. "
        "Maintain a supportive and empathetic tone."
    )
    response = model.generate_content(
        f"{context}\n\nUser: {user_message}\nRakshak:"
    )
    
    return jsonify({
        'response': response.text,
        'location': user_location
    })

if __name__ == '__main__':
    app.run(debug=True)